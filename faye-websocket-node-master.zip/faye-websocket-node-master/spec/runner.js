require('./faye/websocket/client_spec')
